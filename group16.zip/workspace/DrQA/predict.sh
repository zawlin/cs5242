#!/bin/sh 
python3 predict.py
